# LAVA Training — Insurance Email Simulator (Vercel deployment)

This fixes the "Scoring failed" error you hit on GitHub Pages. GitHub Pages
only serves static files — it cannot keep an API key secret, and the browser
can't call api.anthropic.com directly without one. This version adds a tiny
serverless function that holds the key on the server and the page calls that
instead.

## What changed

- `public/index.html` — same app as before, except the scoring fetch now
  calls `/api/score` instead of `https://api.anthropic.com/v1/messages`
  directly.
- `api/score.js` — a Vercel serverless function. It receives the prompt from
  the browser, attaches your Anthropic API key server-side, calls Anthropic,
  and returns the result. The key never reaches the browser or the repo.
- `vercel.json` — tells Vercel how to route `/api/score` to the function and
  serve everything else as static files.

## Deploy steps

1. **Push this folder to GitHub** (replace your existing repo contents with
   these three files/folders: `api/`, `public/`, `vercel.json`,
   `package.json`).

2. **Import the repo into Vercel** (if not already):
   - vercel.com → Add New → Project → select the GitHub repo.
   - Framework preset: "Other" (it's not Next.js/React, just static + one
     function — Vercel auto-detects this fine).

3. **Add your API key as an environment variable** (this is the step that
   actually fixes the bug):
   - In the Vercel project → Settings → Environment Variables.
   - Add a variable named exactly `ANTHROPIC_API_KEY` with your key as the
     value.
   - Apply it to Production (and Preview/Development if you test those).
   - Get an API key from https://console.anthropic.com/settings/keys if you
     don't have one yet.

4. **Redeploy.** Either push a new commit, or click "Redeploy" in the Vercel
   dashboard so the new environment variable takes effect.

5. **Test it.** Open the deployed `*.vercel.app` URL, pick a scenario, write
   an email (50+ characters), click "Submit & Score". It should now return a
   real score instead of "Scoring failed."

## If it still fails

Open the browser console (F12) before clicking Submit & Score this time —
the error handling now surfaces the real reason, for example:

- `"Server misconfigured: ANTHROPIC_API_KEY is not set..."` → the env var
  isn't set, or you forgot to redeploy after adding it.
- A 401 or 403 from Anthropic → the key itself is invalid, expired, or out
  of credits.
- Anything else → check the Vercel function logs (Project → Deployments →
  click the deployment → Functions tab → `api/score`) for the server-side
  stack trace.

## Note on GitHub Pages

Keep using GitHub for source control if you like, but the live site itself
needs to run on Vercel (or any host that supports serverless functions /
a backend) — GitHub Pages alone can never make this scoring feature work
because it has no way to protect the API key.
